var app = angular.module('foodApp', ['ngRoute']);

app.config(function($routeProvider) {
  $routeProvider
    .when('/', {
      templateUrl: 'login.html',
      controller: 'LoginController'
    })
    .when('/menu', {
      templateUrl: 'menu.html',
      controller: 'MenuController'
    })
    .when('/cart', {
      templateUrl: 'cart.html',
      controller: 'CartController'
    })
    .when('/payment', {
      templateUrl: 'payment.html',
      controller: 'PaymentController'
    })
    .when('/confirmation', {
      templateUrl: 'confirmation.html',
      controller: 'ConfirmationController'
    })
    .otherwise({
      redirectTo: '/'
    });
});

app.service('CartService', function() {
  var cart = [];
  var totalPrice = 0;

  // Load cart from localStorage on initialization
  this.loadCart = function() {
    var saved = localStorage.getItem('cart');
    if (saved) {
      cart = JSON.parse(saved);
      this.calculateTotal();
    }
  };

  // Save cart to localStorage
  this.saveCart = function() {
    localStorage.setItem('cart', JSON.stringify(cart));
  };

  // Initialize by loading
  this.loadCart();

  return {
    getCart: function() {
      return cart;
    },
    addToCart: function(item) {
      var existingItem = cart.find(function(cartItem) {
        return cartItem.id === item.id;
      });
      if (existingItem) {
        existingItem.quantity++;
      } else {
        cart.push(angular.copy(item));
        cart[cart.length - 1].quantity = 1;
      }
      this.calculateTotal();
      this.saveCart();
    },
    removeFromCart: function(item) {
      var index = cart.indexOf(item);
      if (index > -1) {
        cart.splice(index, 1);
      }
      this.calculateTotal();
      this.saveCart();
    },
    updateQuantity: function(item) {
      if (item.quantity <= 0) {
        this.removeFromCart(item);
      } else {
        this.calculateTotal();
        this.saveCart();
      }
    },
    increaseQuantity: function(item) {
      item.quantity++;
      this.calculateTotal();
      this.saveCart();
    },
    decreaseQuantity: function(item) {
      if (item.quantity > 1) {
        item.quantity--;
        this.calculateTotal();
        this.saveCart();
      }
    },
    calculateTotal: function() {
      totalPrice = cart.reduce(function(total, item) {
        return total + (item.price * item.quantity);
      }, 0);
      totalPrice = Math.round(totalPrice * 100) / 100;
    },
    getTotalPrice: function() {
      return totalPrice;
    },
    clearCart: function() {
      cart = [];
      totalPrice = 0;
      this.saveCart();
    },
    getItemCount: function() {
      return cart.length;
    }
  };
});

app.controller('LoginController', function($scope, $location) {
  $scope.username = '';
  $scope.password = '';

  // Check if user is logged in
  if (localStorage.getItem('isLoggedIn') === 'true') {
    $location.path('/menu');
  }

  $scope.login = function() {
    if ($scope.username && $scope.password) {
      localStorage.setItem('isLoggedIn', 'true');
      $location.path('/menu');
    } else {
      alert('Please enter username and password');
    }
  };
});

app.controller('MenuController', function($scope, $http, CartService, $location) {
  $scope.menu = [];
  $scope.loading = true;
  $scope.cart = CartService.getCart();

  // Check login
  if (localStorage.getItem('isLoggedIn') !== 'true') {
    $location.path('/');
    return;
  }

  $http.get('/menu').then(function(response) {
    $scope.menu = response.data;
    $scope.loading = false;
  }, function(error) {
    console.error('Error fetching menu:', error);
    $scope.loading = false;
  });

  $scope.addToCart = function(item) {
    CartService.addToCart(item);
  };
});

app.controller('CartController', function($scope, CartService, $location) {
  // Check login
  if (localStorage.getItem('isLoggedIn') !== 'true') {
    $location.path('/');
    return;
  }

  $scope.cart = CartService.getCart();
  $scope.totalPrice = CartService.getTotalPrice();

  $scope.removeFromCart = function(item) {
    CartService.removeFromCart(item);
    $scope.totalPrice = CartService.getTotalPrice();
  };

  $scope.updateQuantity = function(item) {
    CartService.updateQuantity(item);
    $scope.totalPrice = CartService.getTotalPrice();
  };

  $scope.increaseQuantity = function(item) {
    CartService.increaseQuantity(item);
    $scope.totalPrice = CartService.getTotalPrice();
  };

  $scope.decreaseQuantity = function(item) {
    CartService.decreaseQuantity(item);
    $scope.totalPrice = CartService.getTotalPrice();
  };

  $scope.proceedToCheckout = function() {
    $location.path('/payment');
  };
});

app.controller('PaymentController', function($scope, $http, CartService, $location) {
  // Check login
  if (localStorage.getItem('isLoggedIn') !== 'true') {
    $location.path('/');
    return;
  }

  $scope.cart = CartService.getCart();
  $scope.totalPrice = CartService.getTotalPrice();
  $scope.deliveryFee = 2.99;
  $scope.tax = $scope.totalPrice * 0.08;
  $scope.finalTotal = $scope.totalPrice + $scope.deliveryFee + $scope.tax;

  $scope.deliveryInfo = {};
  $scope.paymentInfo = {};

  $scope.processPayment = function() {
    if (!$scope.deliveryInfo.firstName || !$scope.deliveryInfo.lastName || !$scope.deliveryInfo.email || 
        !$scope.deliveryInfo.phone || !$scope.deliveryInfo.address || !$scope.deliveryInfo.city || 
        !$scope.deliveryInfo.state || !$scope.deliveryInfo.zipCode ||
        !$scope.paymentInfo.cardNumber || !$scope.paymentInfo.expiryDate || !$scope.paymentInfo.cvv || 
        !$scope.paymentInfo.cardholderName) {
      alert('Please fill in all required fields');
      return;
    }

    var order = {
      items: $scope.cart,
      deliveryInfo: $scope.deliveryInfo,
      paymentInfo: $scope.paymentInfo,
      subtotal: $scope.totalPrice,
      deliveryFee: $scope.deliveryFee,
      tax: $scope.tax,
      total: $scope.finalTotal,
      timestamp: new Date()
    };

    $http.post('/order', order).then(function(response) {
      CartService.clearCart();
      $location.path('/confirmation').search({orderId: response.data.orderId, total: $scope.finalTotal});
    }, function(error) {
      console.error('Error processing payment:', error);
      alert('Payment failed. Please try again.');
    });
  };
});

app.controller('ConfirmationController', function($scope, $location) {
  // Check login
  if (localStorage.getItem('isLoggedIn') !== 'true') {
    $location.path('/');
    return;
  }

  var params = $location.search();
  $scope.orderId = params.orderId;
  $scope.totalPaid = params.total;
  $scope.orderItems = []; // In a real app, you'd fetch this from the server

  // For demo, we'll just show a message
});

app.run(function($rootScope, CartService) {
  $rootScope.isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
  $rootScope.cart = CartService.getCart();
  $rootScope.logout = function() {
    $rootScope.isLoggedIn = false;
    CartService.clearCart();
    localStorage.removeItem('isLoggedIn');
    window.location.href = '/';
  };
});