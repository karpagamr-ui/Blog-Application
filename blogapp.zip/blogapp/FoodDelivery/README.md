# Food Delivery App

A fully functional online food ordering web application built with modern web technologies and AngularJS routing.

## Features

- **User Authentication**: Login system with persistent sessions
- **Responsive Design**: Works on both desktop and mobile devices
- **Dynamic Menu**: Browse food items with images, descriptions, and prices
- **Advanced Cart Management**: Add, remove, and update items with quantity controls
- **Checkout Process**: Multi-step checkout with delivery and payment information
- **Order Processing**: Complete payment flow with confirmation
- **Real-time Updates**: Cart count and totals update instantly

## Technologies Used

- **Frontend**: HTML, CSS, JavaScript, AngularJS with ngRoute
- **Backend**: Node.js, Express
- **Styling**: Bootstrap for responsive design
- **HTTP Requests**: AngularJS $http service
- **Routing**: AngularJS ngRoute for SPA navigation

## Installation

1. Make sure you have Node.js installed on your system.

2. Clone or download this repository.

3. Navigate to the project directory:
   ```
   cd FoodDelivery
   ```

4. Install dependencies:
   ```
   npm install
   ```

5. Start the server:
   ```
   npm start
   ```

6. Open your browser and go to `http://localhost:3000`

## Usage

1. **Login**: Enter any username/password combination
2. **Browse Menu**: View available food items and add to cart
3. **Manage Cart**: Adjust quantities, remove items, view totals
4. **Checkout**: Enter delivery and payment information
5. **Payment**: Complete the order and receive confirmation

## Project Structure

```
FoodDelivery/
├── public/
│   ├── index.html          # Main application page with routing
│   ├── login.html          # Login page template
│   ├── menu.html           # Menu page template
│   ├── cart.html           # Cart page template
│   ├── payment.html        # Payment page template
│   ├── confirmation.html   # Confirmation page template
│   ├── styles.css          # Custom styling
│   └── app.js              # AngularJS application with routing
├── server.js               # Express server
├── menu.json               # Menu data
├── package.json            # Dependencies
└── README.md               # This file
```

## Features in Detail

### Cart Functionality
- Add items with automatic quantity increment
- Increase/decrease quantities with +/- buttons
- Remove items completely
- Real-time total calculation
- Persistent cart across page navigation

### Payment Process
- Delivery information collection
- Payment details form
- Order summary with fees and taxes
- Validation for all required fields
- Secure order submission

### User Experience
- Single Page Application with smooth navigation
- Loading states and error handling
- Responsive design for all devices
- Intuitive user interface

## Troubleshooting

- If the server doesn't start, make sure port 3000 is available
- Check the console for any error messages
- Ensure all dependencies are installed correctly
- Clear browser cache if experiencing routing issues

## Future Enhancements

- User registration and profiles
- Order history and tracking
- Multiple payment methods
- Admin panel for menu management
- Real-time order status updates